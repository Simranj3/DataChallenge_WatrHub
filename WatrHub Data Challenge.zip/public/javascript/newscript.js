var test = [
{
  "question":"How Many Water Plants are there in Ajax?",
  "correctIndex": 3,
  "correctLetter": "D",
  "options": ["A: a lot"," B: 0 "," C: 16 "," D: this is correct "],
  "coolFact": "Here is a super cool fact about water plants in Ajax, yaaay"
},
{
  "question":"Is WatrHub Awesome?",
  "correctIndex": 0,
  "correctLetter": "A",
  "options": ["A: correct"," B: No"," C: All of the above","D: 21"],
  "coolFacts": " More cool facts hahahah"
},

{
  "question":"what is my fave colour?",
  "correctIndex": 3,
  "correctLetter": "D",
  "options": ["A: purple","B: No","C: All of the above","D: I am correct"],
  "coolFacts": " More cool facts hahahah"
},

{
  "question":"What are WatrHub Colours?",
  "correctIndex": 3,
  "correctLetter": "D",
  "options": ["A: Yes","B: orange","C: yellow","D: pick me pls"],
  "coolFacts": " More cool facts hahahah"
},

{
  "question":"Is xmas amazing?",
  "correctIndex": 1,
  "correctLetter": "B",
  "options": ["A: lawl","B: obviously (correct)","C: santa","D: 21"],
  "coolFacts": " More cool facts hahahah"
}
]


var currentQuestion;
var gameTimer;
var score = 0; 
var paused = false;

function loadQuestion(question) {
  $("#question").html(question['question']);

  var answersDom = $('.questionblock')
  for (var i = 0; i < answersDom.length; i++) {
    $(answersDom[i]).data('correct', i == question['correctIndex']);
    $(answersDom[i]).html(question['options'][i]);
  }
  currentQuestion = question;

  var currentName = localStorage.getItem('name');
  console.log(currentName);

  $("#usersname").html(currentName); //move 
  startTimer(15, $('#time'));
  console.log("time is running out");
}

// TIME FUNCTION 
function startTimer(duration, display) {
    var timer = duration, minutes, seconds;
    if (gameTimer) {
      clearInterval(gameTimer);
    }
    gameTimer = setInterval(function () {
      if (!paused){
        minutes = parseInt(timer / 60, 10)
        seconds = parseInt(timer % 60, 10);

        minutes = minutes < 10 ? "0" + minutes : minutes;
        seconds = seconds < 10 ? "0" + seconds : seconds;

        display.text(minutes + ":" + seconds);

        if (seconds == 05) { 
          $("time").addClass("danger");
        }
        if (--timer < 0) {
            //timer = duration;
            openTimeModal();
                $(".additionalInfo").html(currentQuestion['coolFacts']);
              $(".correctLetter").html(currentQuestion['correctLetter']);
       
            clearInterval(gameTimer);
        }
      }
    }, 1000);
}



// UNIQUE RANDOMS 
var uniqueRandoms = [];
var numRandoms = 4; 
function makeUniqueRandom() { 
  if (!uniqueRandoms.length){ 
    for (var i=0; i < numRandoms; i++) { 
      uniqueRandoms.push(i);
    }
  }

  var index = Math.floor(Math.random() * uniqueRandoms.length);
  var val = uniqueRandoms[index];

  uniqueRandoms.splice(index, 1); 
  console.log(val);

  return val; 
}



$(document).keyup(function(e) { 
    if (e.keyCode == 80) { 
      openPauseModal();

    } 
});



function ridScreen() {
$('#screen').css({'visibility': 'hidden'});
}


function openCorrectModal() {
  el = document.getElementById("correctModal");
  el.style.visibility = (el.style.visibility == "visible") ? "hidden" : "visible";
  $('#screen').css({'width':$(document).width(),'height':$(document).height()});
}

function openCongratsModal() {
  el = document.getElementById("congratsModal");
  el.style.visibility = (el.style.visibility == "visible") ? "hidden" : "visible";
   $('#screen').css({'width':$(document).width(),'height':$(document).height()});
}

function openIncorrectModal() {
  el = document.getElementById("incorrectModal");
  el.style.visibility = (el.style.visibility == "visible") ? "hidden" : "visible";
  $('#screen').css({'width':$(document).width(),'height':$(document).height()});

}

function openTimeModal() {
  el = document.getElementById("timeModal");
  el.style.visibility = (el.style.visibility == "visible") ? "hidden" : "visible";
  $('#screen').css({'width':$(document).width(),'height':$(document).height()});
}

function openPauseModal() {
  el = document.getElementById("pauseModal");
  el.style.visibility = (el.style.visibility == "visible") ? "hidden" : "visible";
  $('#screen').css({'width':$(document).width(),'height':$(document).height()});
  paused = !paused;
}

function openExitModal() {
  el = document.getElementById("exitModal");
  el.style.visibility = (el.style.visibility == "visible") ? "hidden" : "visible";
  $('#screen').css({'width':$(document).width(),'height':$(document).height()})

}

function addNew() {
  $("#starsTog ul").append('<li  style="width:25px"> <img src="star.png" class="small"> </li>').addClass("animated rubberBand");
}


$(".questionblock").click(function() {
  var correct = $(this).data('correct');

    if (correct) {
      if (score == 6){ 
        openCongratsModal(); 
          // $(".additionalInfo").html(currentQuestion['coolFacts']);
         //  $(".correctLetter").html(currentQuestion['correctLetter']);
       
         
      }

          else {
          //You are correct!
          openCorrectModal();
          $(".additionalInfo").html(currentQuestion['coolFacts']);
          $(".correctLetter").html(currentQuestion['correctLetter']);
           $("#stars").append('<li  style="width:25px"> <img src="star.png" class="small"> </li>');
           $("#stars li:last").addClass("animated rubberBand");

          paused = !paused;

          
          //add one point to score 
          score = score + 1; 
          addNew(); //idk how to get it to animate every single time 
          
       

          
      }
    } else {
      openIncorrectModal();
      //$(".additionalInfo").html(currentQuestion['coolFacts']);
      //$(".correctLetter").html(currentQuestion['correctLetter']);
      paused = !paused;
       
  }
});

function gameDone() {
  //Go to summary screen/modal window 
  // save users data
  // update the scoreboard/automatic refresh 
  //TODO: Get Score

  var golfScore = 0;
  for (i=0; i < 3; i++) { 

    var val = $($('.gScore')[i]).val();
    if (val != "") {
      golfScore = parseInt(val);
    }
  }

  var send_score = score;
  $.post('/save_score', {'score': send_score, 'timestamp': new Date().getTime(), 'gscore': golfScore })
  //GOLF SCORE 
  score = 0;
  console.log("you are finished!");
}




//var num = Math.floor(Math.random() * (5 - 0 + 1)) + 0;
 

loadQuestion(test[makeUniqueRandom()]);
